const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const os = require('os');
const https = require('https');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const { initDatabase, seedInitialData } = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const attendanceRoutes = require('./routes/attendanceRoutes');
const documentRoutes = require('./routes/documentRoutes');
const milestoneRoutes = require('./routes/milestoneRoutes');
const fileRoutes = require('./routes/fileRoutes');
const unifiedRoutes = require('./routes/unifiedRoutes');
const syncRoutes = require('./routes/syncRoutes');
const dataRoutes = require('./routes/dataRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 3000;

// Trust nginx reverse proxy (sets req.ip, req.protocol correctly on production)
app.set('trust proxy', 1);

// Middleware - Allow all origins for multi-device access
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

// Request logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// ============================================
// API Routes
// ============================================
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/milestones', milestoneRoutes);
app.use('/api/files', fileRoutes);
app.use('/api/unified', unifiedRoutes);
app.use('/api/sync', syncRoutes);
app.use('/api/data', dataRoutes);

// Health check with server info
app.get('/api/health', (req, res) => {
    const networkInterfaces = os.networkInterfaces();
    const addresses = [];
    for (const iface of Object.values(networkInterfaces)) {
        for (const config of iface) {
            if (config.family === 'IPv4' && !config.internal) {
                addresses.push(config.address);
            }
        }
    }
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        server: {
            hostname: os.hostname(),
            ip: addresses,
            port: PORT,
            uptime: process.uptime()
        }
    });
});

// ============================================
// Serve Frontend Static Files
// ============================================
const FRONTEND_ROOT = path.join(__dirname, '..');

// ============================================
// Virtual Host Portal Routing
// Maps <domain>/system/* to the correct portal
// dheekaybuilders.com/system  → dheekay portal
// kdchavitconstruction.com/system → kdchavit portal
// ============================================
const VIRTUAL_HOST_PORTALS = {
    'dheekaybuilders.com':      'dheekay',
    'kdchavitconstruction.com': 'kdchavit',
};

app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) return next(); // never intercept API
    const host = (req.headers.host || '').replace(/^www\./, '').split(':')[0];
    const portalFolder = VIRTUAL_HOST_PORTALS[host];
    if (!portalFolder) return next();

    // Redirect bare domain root → /system/
    if (req.path === '/' || req.path === '') return res.redirect(302, '/system/');

    // Redirect bare /system to /system/ so relative asset paths resolve correctly
    if (req.path === '/system') return res.redirect(301, '/system/');

    if (req.path.startsWith('/system')) {
        const subPath = req.path.slice('/system'.length) || '/index.html';
        const target = subPath === '/' ? 'index.html' : subPath.replace(/^\//, '');
        const filePath = path.join(FRONTEND_ROOT, portalFolder, target);
        if (fs.existsSync(filePath)) return res.sendFile(filePath);
        // SPA fallback — serve portal index for unknown sub-paths
        return res.sendFile(path.join(FRONTEND_ROOT, portalFolder, 'index.html'));
    }

    // For all other paths on a portal domain (css/js/images etc.), serve from root
    next();
});

// Serve individual business portals (LAN / direct-port access)
app.use('/dheekay', express.static(path.join(FRONTEND_ROOT, 'dheekay')));
app.use('/kdchavit', express.static(path.join(FRONTEND_ROOT, 'kdchavit')));
app.use('/nuatthai', express.static(path.join(FRONTEND_ROOT, 'nuatthai')));
app.use('/autocasa', express.static(path.join(FRONTEND_ROOT, 'autocasa')));

// Serve shared assets
app.use('/css', express.static(path.join(FRONTEND_ROOT, 'css')));
app.use('/js', express.static(path.join(FRONTEND_ROOT, 'js')));
app.use('/images', express.static(path.join(FRONTEND_ROOT, 'images')));
app.use('/assets', express.static(path.join(FRONTEND_ROOT, 'assets')));

// Serve Service Worker at root scope
app.get('/sw.js', (req, res) => {
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Service-Worker-Allowed', '/');
    res.sendFile(path.join(FRONTEND_ROOT, 'sw.js'));
});

// Serve Time In/Out kiosk
app.get('/timeinout', (req, res) => {
    res.sendFile(path.join(FRONTEND_ROOT, 'timeinout.html'));
});
app.get('/timeinout.html', (req, res) => {
    res.sendFile(path.join(FRONTEND_ROOT, 'timeinout.html'));
});

// Serve login page
app.get('/login', (req, res) => {
    res.sendFile(path.join(FRONTEND_ROOT, 'login.html'));
});
app.get('/login.html', (req, res) => {
    res.sendFile(path.join(FRONTEND_ROOT, 'login.html'));
});

// Serve unified main app (index.html) at root
app.get('/', (req, res) => {
    res.sendFile(path.join(FRONTEND_ROOT, 'index.html'));
});
app.get('/index.html', (req, res) => {
    res.sendFile(path.join(FRONTEND_ROOT, 'index.html'));
});

// 404 handler for unmatched routes
app.use((req, res) => {
    // If requesting an API route, return JSON 404
    if (req.path.startsWith('/api/')) {
        return res.status(404).json({ success: false, error: 'API route not found' });
    }
    // For all other routes, serve the main app (SPA routing)
    res.sendFile(path.join(FRONTEND_ROOT, 'index.html'));
});

// Global error handler
app.use(errorHandler);

// Initialize database and start server
async function startServer() {
    try {
        console.log('🔧 Initializing database...');
        await initDatabase();
        
        console.log('🌱 Seeding initial data...');
        await seedInitialData();
        
        // Listen on all network interfaces (0.0.0.0) so other devices can connect
        const server = app.listen(PORT, '0.0.0.0', () => {
            const networkInterfaces = os.networkInterfaces();
            const addresses = [];
            for (const [name, iface] of Object.entries(networkInterfaces)) {
                for (const config of iface) {
                    if (config.family === 'IPv4' && !config.internal) {
                        addresses.push({ name, address: config.address });
                    }
                }
            }

            console.log(`\n${'='.repeat(60)}`);
            console.log(`  UBMS - Unified Business Management System`);
            console.log(`  Server is ONLINE and ready for connections`);
            console.log(`${'='.repeat(60)}`);
            console.log(`\n🌐 Access URLs:`);
            console.log(`   Local:    http://localhost:${PORT}`);
            addresses.forEach(a => {
                console.log(`   Network:  http://${a.address}:${PORT}  (${a.name})`);
            });
            console.log(`\n📚 API Endpoints:`);
            console.log(`   Auth:       POST /api/auth/login, /api/auth/superadmin, /api/auth/reset-password`);
            console.log(`   Users:      GET|POST /api/users, GET|PUT|DELETE /api/users/:id`);
            console.log(`   Attendance: GET|POST /api/attendance, PUT /api/attendance/:id/clockout`);
            console.log(`   Documents:  GET|POST /api/documents, GET /api/documents/:id/download`);
            console.log(`   Files:      POST /api/files/upload, GET /api/files/business/:biz`);
            console.log(`   Milestones: GET|POST /api/milestones`);
            console.log(`   Unified:    GET /api/unified/dashboard, /api/unified/businesses, /api/unified/config`);
            console.log(`   Sync:       GET /api/sync/stream (SSE), POST /api/sync/changes, /api/sync/bulk`);
            console.log(`   Data:       POST /api/data/import, GET /api/data/export, GET /api/data/:type, GET /api/data/user/:userId`);
            console.log(`\n🏢 Business Portals (LAN):`);
            console.log(`   Unified:    http://localhost:${PORT}/`);
            console.log(`   Dheekay:    http://localhost:${PORT}/dheekay/`);
            console.log(`   KDChavit:   http://localhost:${PORT}/kdchavit/`);
            console.log(`   NuatThai:   http://localhost:${PORT}/nuatthai/`);
            console.log(`   AutoCasa:   http://localhost:${PORT}/autocasa/`);
            console.log(`   Time Clock: http://localhost:${PORT}/timeinout`);
            console.log(`\n🌐 Production URLs:`);
            console.log(`   Dheekay:    https://dheekaybuilders.com/system/`);
            console.log(`   KDChavit:   https://kdchavitconstruction.com/system/`);
            addresses.forEach(a => {
                console.log(`\n   📱 Share this URL for online access:`);
                console.log(`      http://${a.address}:${PORT}`);
            });
            console.log(`\n💡 Default Super Admin: superadmin / DK-SA-7829-UBMS`);
            console.log(`${'='.repeat(60)}\n`);
        });

        server.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                console.error(`❌ Port ${PORT} is already in use.`);
                console.error(`   Kill the existing process or set a different PORT in .env`);
                process.exit(1);
            } else {
                throw err;
            }
        });

        // HTTPS server for GitHub Pages (HTTPS → HTTPS, no mixed content)
        const HTTPS_PORT = process.env.HTTPS_PORT || 3443;
        const pfxPath = path.join(__dirname, 'certs', 'server.pfx');
        if (fs.existsSync(pfxPath)) {
            try {
                const httpsOptions = {
                    pfx: fs.readFileSync(pfxPath),
                    passphrase: process.env.PFX_PASS || 'ubms2026'
                };
                const httpsServer = https.createServer(httpsOptions, app);
                httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
                    console.log(`\n🔒 HTTPS server running on port ${HTTPS_PORT}`);
                    const addresses = [];
                    for (const iface of Object.values(os.networkInterfaces())) {
                        for (const config of iface) {
                            if (config.family === 'IPv4' && !config.internal) addresses.push(config.address);
                        }
                    }
                    addresses.forEach(a => {
                        console.log(`   🔐 https://${a}:${HTTPS_PORT}`);
                    });
                    console.log(`   ⚠️  Self-signed cert — browsers will warn on first visit. Click "Advanced" → "Proceed".`);
                    console.log(`   💡 GitHub Pages users connect via: https://<IP>:${HTTPS_PORT}`);
                });
            } catch (e) {
                console.warn('⚠️ HTTPS setup failed (non-fatal):', e.message);
            }
        } else {
            console.log('\nℹ️  No certs/server.pfx found — HTTPS disabled. Run: node generate-cert.js');
        }
    } catch (err) {
        console.error('❌ Failed to start server:', err);
        process.exit(1);
    }
}

startServer();

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down gracefully...');
    process.exit(0);
});
